#ifndef PLATFORM_H
#define PLATFORM_H

#include "../Entity.h"

class Platform : public Entity {
public:
    Platform(int posX, int posY, int width, int height, int speedX, int speedY);

    ~Platform();

    char getState() override;
};

#endif //PLATFORM_H
